﻿

namespace Application.DTOs
{
    //Thông báo
    public record PeopleResponse(bool Flag, string Message = null!);
}
